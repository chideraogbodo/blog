<?php
// Directory where the uploaded images will be saved
$target_dir = "upload/";
$uploadOk = 1;

// Check if the file was uploaded
if (!isset($_FILES['photo'])) {
    die("Error: No file uploaded.<br>");
}

// Check for upload errors
if ($_FILES['photo']['error'] != UPLOAD_ERR_OK) {
    switch ($_FILES['photo']['error']) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            die("Error: File size exceeds the allowed limit.<br>");
        case UPLOAD_ERR_PARTIAL:
            die("Error: File was only partially uploaded.<br>");
        case UPLOAD_ERR_NO_FILE:
            die("Error: No file was uploaded.<br>");
        case UPLOAD_ERR_NO_TMP_DIR:
            die("Error: No temporary directory available.<br>");
        case UPLOAD_ERR_CANT_WRITE:
            die("Error: Failed to write file to disk.<br>");
        case UPLOAD_ERR_EXTENSION:
            die("Error: File upload stopped by extension.<br>");
        default:
            die("Error: Unknown upload error.<br>");
    }
}

// Validate and process the file
$target_file = $target_dir . basename($_FILES['photo']['name']);
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

// Check if the file is an actual image
$check = getimagesize($_FILES["photo"]["tmp_name"]);
if ($check !== false) {
    echo "File is an image - " . $check["mime"] . ".<br>";
} else {
    die("File is not an image.<br>");
}

// Check if file already exists
if (file_exists($target_file)) {
    die("Sorry, file already exists.<br>");
}

// Check file size (e.g., limit to 5MB)
if ($_FILES["photo"]["size"] > 5000000) { // 5MB
    die("Sorry, your file is too large.<br>");
}

// Allow certain file formats (e.g., JPG, JPEG, PNG, GIF)
$allowedTypes = ["jpg", "jpeg", "png", "gif"];
if (!in_array($imageFileType, $allowedTypes)) {
    die("Sorry, only JPG, JPEG, PNG & GIF files are allowed.<br>");
}

// Attempt to move the uploaded file to the target directory
if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
    echo "The file " . htmlspecialchars(basename($_FILES["photo"]["name"])) . " has been uploaded.<br>";
    // Redirect to edit_post.php with the uploaded file name
    header("Location: edit_post.php?image=" . urlencode(basename($_FILES["photo"]["name"])));
    exit();
} else {
    die("Sorry, there was an error uploading your file.<br>");
}
?>
