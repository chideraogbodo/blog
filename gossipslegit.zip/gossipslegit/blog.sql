-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 04, 2024 at 12:52 PM
-- Server version: 5.5.16
-- PHP Version: 5.4.0beta2-dev

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(2, 'Programming'),
(3, 'Music'),
(4, 'African News'),
(6, 'Earth'),
(7, 'Celebrity News'),
(8, 'Social Media'),
(9, 'Technology');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `cat_id` int(3) NOT NULL,
  `title` varchar(255) NOT NULL,
  `contents` text NOT NULL,
  `date_posted` datetime NOT NULL,
  `pics` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `cat_id`, `title`, `contents`, `date_posted`, `pics`) VALUES
(6, 2, 'What is programming today?', 'â€œProgramming today is a race between software engineers striving to build bigger and better idiot-proof programs, and the Universe trying to produce bigger and better idiots. So far, the Universe is winning.â€ \r\nâ€• Rick Cook, The Wizardry Compiled', '2017-10-06 15:50:31', ''),
(8, 3, 'Music <3', 'â€œMusic has always been a matter of Energy to me, a question of Fuel. Sentimental people call it Inspiration, but what they really mean is Fuel. I have always needed Fuel. I am a serious consumer. On some nights I still believe that a car with the gas needle on empty can run about fifty more miles if you have the right music very loud on the radio.â€ \r\nâ€• Hunter S. Thompson', '2017-10-06 15:53:36', ''),
(10, 6, 'Honey, not marmalade, is saving the real ''Paddington Bear''', 'lsa Limachi looks silently at the mountains around her small straw house. She is scanning her surroundings for the Andean bear. This small "spectacled" bear, with its circular golden markings around its eyes, is the real-life Paddington Bear.\r\nUnlike the marmalade-obsessed fictional favourite, Andean bears are not social creatures. They are difficult to spot, but they are there, roaming through the dry Andean forest in southern Bolivia, Limachi says. \r\nThe inter-Andean dry forest lives up to its name with a landscape dotted with dense trees and bushes, where green merges with yellow and brown. The earthy tones of the landscape provide the perfect camouflage for the Andean bear''s dark brown fur.\r\nLimachi lives in San Lorencito, a remote farming village in Tarija, southern Bolivia. For generations, the community saw the Andean bear as a threat which was responsible for killing their cattle and eating their crops. These often false beliefs have led to retaliatory killings in the area.', '2017-10-06 15:56:16', ''),
(11, 7, 'Yeah! People!', 'People don`t change, but they can learn to behave differently.     \r\n\r\nCharlaine Harris', '2017-10-06 15:57:18', ''),
(12, 8, 'Sport', 'â€œSocial media is about sociology and psychology more than technology.â€ â€“ Brian Solis', '2017-10-06 15:58:33', ''),
(13, 9, 'Technology!', 'All of the biggest technological inventions created by man - the airplane, the automobile, the computer - says little about his intelligence, but speaks volumes about his laziness. - Mark Kennedy.', '2017-10-06 15:59:26', ''),
(14, 8, 'Kamala Harris pledges ''new way forward'' in historic convention speech', 'Vice-President Kamala Harris pledged a "new way forward" for all Americans as she formally accepted the Democratic nomination for president on Thursday night, delivering a message of unity and urging voters to reject Donald Trump.\r\nNovember''s election is a chance to "move past the bitterness, cynicism and divisive battles of the past", she said, bringing her party''s convention in Chicago to a close as balloons rained down and supporters cheered.\r\nMs Harris''s speech capped off a four-day spectacle designed to highlight her backstory and shape the contours of what remains a vague policy agenda.\r\nShe made history as the first black and Asian-American woman to lead a major party''s presidential ticket.', '2024-08-23 03:19:48', ''),
(15, 9, 'Hospitals keep AI technology after cancer trial', 'A hospital trust will continue to use AI technology after a trial found the software helped find bowel lesions which could become cancerous.\r\nSouth Tyneside and Sunderland NHS Foundation Trust (STSFT) has been using a computer module called the GI Genius AI device during colonoscopies - a procedure which uses a camera to look inside a person''s bowel.\r\nOn average the new technology found an extra 0.36 lesions - known as adenomas - during each colonoscopy, it said.\r\nProf Colin Rees, a consultant gastroenterologist at the trust, said the new equipment would "save lives".', '2024-08-25 03:50:12', ''),
(16, 4, 'Nigerian governor WhatsApp number hacked by fraudsters', 'Suspected fraudsters have hacked the WhatsApp number of Umo Eno, the governor of Nigeriaâ€™s oil-rich Akwa Ibom state, and asked his contacts for money.\r\nAkwa Ibom, in southern Nigeria, is the countryâ€™s third-richest state based on its annual gross domestic product of $19bn (Â£15bn).\r\nThe governor, a pastor who founded the All Nations Christian Ministry International, was elected last year.\r\nMany of Mr Eno''s phone contacts received messages from his WhatsApp number on Tuesday asking them to transfer a specified amount of money to an account and promising reimbursement later.', '2024-08-25 04:21:25', ''),
(19, 9, '@legitgossips', '@legitgossips\r\nThat is our recent Instagram handle kindle follow now', '2024-08-29 13:04:25', ''),
(20, 4, 'SDDFSVFGNHJ', 'QWEREDFBGFHNYSNGFXCVD\r\nSDFTRY\r\nETAYRHJTDGH\r\nTSJGDHKUFIYUTY', '2024-09-04 05:21:05', ''),
(21, 4, 'qwrtegrhwgnhjteyj', 'ewyrrtehgd', '2024-09-04 05:22:40', ''),
(22, 6, 'qwrtegrhwgnhjteyj', 'ewyrrtehgopppd', '2024-09-04 05:28:07', ''),
(23, 0, 'aryrgfdsv', 'PIOUIHFVSIO8WGUEJBKDA', '2024-09-04 05:37:07', '3'),
(24, 0, 'RRRRaryrgfdsv', 'aadsdd', '2024-09-04 05:47:11', '3'),
(25, 0, 'sdds', 'sdsdsd', '2024-09-04 05:49:51', '7');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `name` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `email`, `password`) VALUES
('blessing', 'blessing@gyahoo.com', '1234'),
('root@localhost', NULL, 'root@localhost');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
