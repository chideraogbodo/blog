<!DOCTYPE html>
<!--[if lt IE 8 ]><html class="no-js ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="no-js ie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js ie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 8)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>

   <!--- Basic Page Needs
   ================================================== -->
   <meta charset="utf-8">
	<title>GOSSIPS LEGIT!</title>
	<meta name="description" content="">  
	<meta name="author" content="">

	<!-- mobile specific metas
   ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

   <!-- CSS
    ================================================== -->
   <link rel="stylesheet" href="css/default.css">
	<link rel="stylesheet" href="css/layout.css">  
	<link rel="stylesheet" href="css/media-queries.css"> 

   <!-- Script
   ================================================== -->
	<script src="js/modernizr.js"></script>

   <!-- Favicons
	================================================== -->
	<link rel="shortcut icon" href="favicon.png" >

</head>

<body>

<!-- Header
   ================================================== -->
   <header id="top">

   	<div class="row">

   		<div class="header-content twelve columns">

		      <h1 id="logo-text"><a href="index.php" title="">GOSSIPS LEGIT!</a></h1>
				<p id="intro">Do you want new Ideas? READ OLD BOOKS!</p>

			</div>			

	   </div>

	   <nav id="nav-wrap"> 

	   	<a class="mobile-btn" href="#nav-wrap" title="Show navigation">Show Menu</a>
		   <a class="mobile-btn" href="#" title="Hide navigation">Hide Menu</a>

	   	<div class="row">    		            

			   	<ul id="nav" class="nav">
			      	<li class="current"><a href="index.php">Home</a></li>																																																																																				
			      	<!--<li class="has-children"><a href="#">Dropdown</a>
	                  <ul>
	                     <li><a href="#">Submenu 01</a></li>
	                     <li><a href="#">Submenu 02</a></li>
	                     <li><a href="#">Submenu 03</a></li>
	                  </ul>
	               </li>
	               <li><a href="demo.html">Demo</a></li>	
	               <li><a href="archives.html">Archives</a></li>
			      	<li class="has-children"><a href="single.html">Blog</a>
							<ul>
	                     <li><a href="blog.html">Blog Entries</a></li>
	                     <li><a href="single.html">Single Blog</a></li>	                     
	                  </ul>
			      	</li>	-->	      	
			      	<li><a href="page.php">About</a></li>
					<li><a href="signup.php">Sign Up</a></li>
			   	</ul> <!-- end #nav -->			   	 

	   	</div> 

	   </nav> <!-- end #nav-wrap --> 	     

   </header> <!-- Header End -->

   <!-- Content
   ================================================== -->
<?php
include_once('resources/init.php');
//$posts = (isset($_GET['id'])) ? get_posts($_GET['id']) : get_posts();
$posts = get_posts((isset($_GET['id']))? $_GET['id'] : null); 
?> 		

<div class="col-md-12 section-1"> 
<h3 style="color: #006633;"> <i class="fa fa-lock"> </i> Log In</h3>

<?php 
	$msg = "";
	if(isset($_POST['submit'])) { 
	$email = $_POST['email']; 
	$password= $_POST['password'];
	$sql= mysqli_query($con, "select * from admin where email='$email' AND password='$password'");
	if ($sql->num_rows> 0) {
	$row = $sql->fetch_array();
	session_start(); 
	$name = $row['name'];
	$_SESSION['email'] = $email ; 
	$msg =" Welcome to GOSSIPS LEGIT ". $name ; 
	$_SESSION['log_name'] = $msg; 
	header('location: dashboard.php');
	}
	else 
	{
	$msg = "Invalid Email or password " . $con->error ;
	}
	}
?>

<form class="" method="post" action="">
<h4> <?php echo $msg;?> </h4> 

<label> Email</label> 
<br />
<input type="email" name="email" class="form-control" id="id_email" placeholder="Enter your Email" required /> <br />
<label>Password </label> 
<br />
<input type="password" name="password" class="form-control" id="id_password" placeholder="Enter Password" required /><br />

<hr /> 

<button class="btn btn-success" title="Click here to Submit" name="submit"> Log In </button>
<a href="index.php" class="btn btn-danger" title="click here to close"> Cancel </a>



</form>
</div>



<div class="col-md-12 section-5">
<footer> 
<hr /> 
<br /> 
<br />
<br />
<p class="copyright">&copy; Copyright 2024. The Blog. &nbsp; Design by <a title="Styleshout">CHIDERA OGBODO</a>.</p>
</footer>
</div>

</div>
</div>

</body>
</html>
