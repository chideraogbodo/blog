<?php
 $con = new mysqli( 'localhost', 'root', '', 'blog' );
  if (!$con) {
    echo "Not connected to database".mysqli_error($con);
  }
  ?>




