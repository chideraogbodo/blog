<?php
include_once('resources/init.php');

// Get posts based on the ID from the URL, if present
$id = isset($_GET['id']) ? $_GET['id'] : null;
$posts = get_posts($id); 
?>
<!DOCTYPE html>
<!--[if lt IE 8 ]><html class="no-js ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="no-js ie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js ie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 8)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>
   <meta charset="utf-8">
   <title>GOSSIPS LEGIT!</title>
   <meta name="description" content="">  
   <meta name="author" content="">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

   <link rel="stylesheet" href="css/default.css">
   <link rel="stylesheet" href="css/layout.css">  
   <link rel="stylesheet" href="css/media-queries.css"> 
   <script src="js/modernizr.js"></script>
   <link rel="shortcut icon" href="favicon.png">

   <script type="text/javascript">
   function confirm_delete() {
       return confirm("Are you sure you want to delete this record?");
   }
   </script>
</head>
<body>

   <header id="top">
      <div class="row">
         <div class="header-content twelve columns">
            <h1 id="logo-text"><a href="index.php" title="">GOSSIPS LEGIT!</a></h1>
            <p id="intro">Do you want new Ideas? READ OLD BOOKS!</p>
         </div>			
      </div>
      <nav id="nav-wrap"> 
         <a class="mobile-btn" href="#nav-wrap" title="Show navigation">Show Menu</a>
         <a class="mobile-btn" href="#" title="Hide navigation">Hide Menu</a>
         <div class="row">    		            
            <ul id="nav" class="nav">
               <li class="current"><a href="index.php">Home</a></li>
               <li><a href="page.php">About</a></li>
            </ul> 
         </div> 
      </nav> 
   </header>

   <div id="content-wrap">
      <div class="row">
         <div id="main" class="eight columns">
            <article class="entry">
            <?php if (!empty($posts)): ?>
               <?php foreach($posts as $post): ?>
                  <header class="entry-header">
                     <h2 class="entry-title">
                        <a href='index.php?id=<?php echo htmlspecialchars($post['post_id']); ?>'><?php echo htmlspecialchars($post['title']); ?></a>
                     </h2>
                     <div class="entry-meta">
                        <ul>
                           <li><?php echo date('d-m-Y H:i:s', strtotime($post['date_posted'])); ?></li>
                           <span class="meta-sep">&bull;</span>								
                           <li>In <a href='manage_category.php?id=<?php echo htmlspecialchars($post['category_id']); ?>'><?php echo htmlspecialchars($post['name']); ?></a></li>
                           <span class="meta-sep">&bull;</span>
                           <li><a href='delete_post.php?id=<?php echo htmlspecialchars($post['post_id']); ?>' onclick='return confirm_delete()'><span style="color:red;">Delete This Post</span></a></li>
                           <li><a href='edit_post.php?id=<?php echo htmlspecialchars($post['post_id']); ?>'><span style="color:blue;">Edit This Post</span></a></li>
                           <li><a href='upload.php?id=<?php echo htmlspecialchars($post['post_id']); ?>'><span style="color:red;">Upload This Post</span></a></li>
                        </ul>
                     </div> 
                  </header> 
                  <div class="entry-content">
                     <p><?php echo nl2br(htmlspecialchars($post['contents'])); ?></p>
                  </div>
               <?php endforeach; ?>
            <?php else: ?>
               <p>No posts available.</p>
            <?php endif; ?>

            <?php
            // File upload handling
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['photo'])) {
                $target_dir = "uploads/";
                $target_file = $target_dir . basename($_FILES["photo"]["name"]);
                $uploadOk = 1;

                // Check for upload errors
                if ($_FILES['photo']['error'] != UPLOAD_ERR_OK) {
                    echo "Error: No file uploaded or upload error.";
                    $uploadOk = 0;
                }

                // Validate image
                $check = getimagesize($_FILES["photo"]["tmp_name"]);
                if ($check !== false) {
                    $uploadOk = 1;
                } else {
                    echo "File is not an image.";
                    $uploadOk = 0;
                }

                // File existence and size checks
                if (file_exists($target_file)) {
                    echo "Sorry, file already exists.";
                    $uploadOk = 0;
                }
                if ($_FILES["photo"]["size"] > 5000000) {
                    echo "Sorry, your file is too large.";
                    $uploadOk = 0;
                }

                // Allowed file formats
                $allowedTypes = ["jpg", "jpeg", "png", "gif"];
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                if (!in_array($imageFileType, $allowedTypes)) {
                    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                    $uploadOk = 0;
                }

                // Upload file if no errors
                if ($uploadOk == 0) {
                    echo "Sorry, your file was not uploaded.";
                } else {
                    if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
                        echo "The file " . htmlspecialchars(basename($_FILES["photo"]["name"])) . " has been uploaded.";
                    } else {
                        echo "Sorry, there was an error uploading your file.";
                    }
                }
            }
            ?>
            </article>
         </div>

         <div id="sidebar" class="four columns">
            <div class="widget widget_search">
               <h3>Search</h3> 
               <form action="#">
                  <input type="text" value="Search here..." onBlur="if(this.value == '') { this.value = 'Search here...'; }" onFocus="if (this.value == 'Search here...') { this.value = ''; }" class="text-search">
                  <input type="submit" value="" class="submit-search">
               </form>
               <h3>
                  <form action="upload.php" method="post" enctype="multipart/form-data">
                     <input type="file" name="photo" />
                     <input type="submit" value="Upload Image" />
                  </form>
               </h3>
            </div>

            <div class="widget widget_categories group">
               <h3>Categories.</h3> 
               <?php foreach(get_categories() as $category): ?>
                  <p><a href="manage_category.php?id=<?php echo htmlspecialchars($category['id']); ?>"><?php echo htmlspecialchars($category['name']); ?></a></p>
               <?php endforeach; ?>
            </div>

            <div class="widget widget_text group">
               <h3>Daily Quote of the Day</h3>
               What is success?
               Success is not final; failure is not fatal
      </div>
         </div> <!-- end sidebar -->
      </div> <!-- end row -->
   </div> <!-- end content-wrap -->

   <!-- Footer -->
   <footer>
      <div class="row"> 
         <p class="copyright">&copy; Copyright 2024. The Blog. &nbsp; Design by <a title="Styleshout">CHIDERA OGBODO</a>.</p>
      </div> <!-- End row -->
      <div id="go-top"><a class="smoothscroll" title="Back to Top" href="#top"><i class="fa fa-chevron-up"></i></a></div>
   </footer> <!-- End Footer-->

   <!-- Java Script -->
   <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
   <script>window.jQuery || document.write('<script src="js/jquery-1.10.2.min.js"><\/script>')</script>
   <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>  
   <script src="js/main.js"></script>
</body>
</html>
