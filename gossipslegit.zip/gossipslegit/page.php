<!DOCTYPE html>
<!--[if lt IE 8 ]><html class="no-js ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="no-js ie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js ie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 8)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>

    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <title>GOSSIPS LEGIT!</title>
    <meta name="description" content="">  
    <meta name="author" content="">

    <!-- Mobile specific metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS -->
    <link rel="stylesheet" href="css/default.css">
    <link rel="stylesheet" href="css/layout.css">  
    <link rel="stylesheet" href="css/media-queries.css"> 

    <!-- Script -->
    <script src="js/modernizr.js"></script>

    <!-- Favicons -->
    <link rel="shortcut icon" href="favicon.png">

</head>

<body>

    <!-- Header -->
    <header id="top">
        <div class="row">
            <div class="header-content twelve columns">
                <h1 id="logo-text"><a href="index.php" title="">GOSSIPS LEGIT!</a></h1>
                <p id="intro">Do you want new Ideas? READ OLD BOOKS!</p>
            </div>			
        </div>

        <nav id="nav-wrap"> 
            <a class="mobile-btn" href="#nav-wrap" title="Show navigation">Show Menu</a>
            <a class="mobile-btn" href="#" title="Hide navigation">Hide Menu</a>
            <div class="row">    		            
                <ul id="nav" class="nav">
                    <li><a href="index.php">Home</a></li>    	
                    <li class="current"><a href="page.php">About</a></li>
                </ul> <!-- end #nav -->			   	 	
            </div> 
        </nav> <!-- end #nav-wrap --> 	
    </header> <!-- Header End -->

    <!-- Content -->
    <div id="content-wrap">
        <div class="row">
            <div id="main" class="eight columns">
                <article class="entry">
                    <header class="entry-header">
                        <h2 class="entry-title"><a title="Styleshout" href="page.php">About</a></h2>  <!-- Removed extra h2 -->
                        <div class="entry-meta">
                            Developer: Chidera Ogbodo<br/>
                            Student of Smart Technology of 2024 Class.
                        </div> 
                    </header> 
                    <div class="entry-content">
                        <p><!--insert here--></p>
                    </div> 
                </article> <!-- end entry -->
            </div> <!-- end main -->

            <div id="sidebar" class="four columns">
                <div class="widget widget_search">
                    <h3>Search</h3> 
                    <form action="#">
                        <input type="text" value="Search here..." onBlur="if(this.value == '') { this.value = 'Search here...'; }" onFocus="if (this.value == 'Search here...') { this.value = ''; }" class="text-search">
                        <input type="submit" value="" class="submit-search">
                    </form>
                </div>

                <div class="widget widget_categories group">
                    <h3><a title="Styleshout" href="#">Videos.</h3></a> 
 <ul><a href="https://youtu.be/5p8e2ZkbOFU" target="_thapa" class="badge shadow text-capitalize" style="color:blue;">Tutorial For New Web Developers</a><br/></ul>
  <ul><a href="https://youtu.be/ItYpuioNizA" target="_thapa" class="badge shadow text-capitalize" style="color:blue;">Nigeria At 64: Live Coverage Of Independence Day Anniversary Celebration</a></ul>

                  </div>
                <div class="widget widget_text group">
                    <h3><a title="Styleshout" href="#">Daily Quote of the Day</h3></a>
                    <p>What is success?</p>
                    <p>"Success is not final; failure is not fatal: It is the courage to continue that counts." - Winston S. Churchill</p>
                </div>
            </div> <!-- end sidebar -->
        </div> <!-- end row -->
    </div> <!-- end content-wrap -->
    
    <!-- Footer -->
    <footer>
        <div class="row"> 
            <p class="copyright">&copy; Copyright 2024. The Blog. &nbsp; Design by <a title="Styleshout" href="#">CHIDERA OGBODO</a>.</p>
        </div> <!-- End row -->
        <div id="go-top"><a class="smoothscroll" title="Back to Top" href="#top"><i class="fa fa-chevron-up"></i></a></div>
    </footer> <!-- End Footer-->

    <!-- Java Script -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.10.2.min.js"><\/script>')</script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>  
    <script src="js/main.js"></script>

</body>
</html>
